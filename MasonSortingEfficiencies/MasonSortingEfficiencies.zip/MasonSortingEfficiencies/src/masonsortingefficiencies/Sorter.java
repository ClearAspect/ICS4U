/*
import java.util.ArrayList;
Roan Mason
05/04/2023

Sorter class that accepts a ArrayList and will sort the numbers and return the sorted arrayList
Using Bubble sort, Insertion sort, Selection sort, Quick Sort, and Merge sort
*/
package masonsortingefficiencies;

public class Sorter {

    // Protected Class Variables
    private boolean ascending = true;

    public Sorter(boolean ascending) {
    }

    public void setAscending() {
        this.ascending = true;
    }

    public void setDescending() {
        this.ascending = false;
    }

    public boolean isAscending() {
        return ascending;
    }

    /* Sorting Methods */

    /**
     * Selection Sorting Method
     * @param array - Array to be sorted
     */
    public void selectionSort(int[] array) {
        int size = array.length;

        for (int step = 0; step < size - 1; step++) {
            int minIndex = step;

            for (int i = step + 1; i < size; i++) {
                if (ascending && (array[i] < array[minIndex])) {
                    minIndex = i;
                } else if (array[i] > array[minIndex]) {
                    minIndex = i;
                }
            }
            int temp = array[step];
            array[step] = array[minIndex];
            array[minIndex] = temp;

        }
    }

    /**
     * Bubble Sorting Method
     * @param array - Array to be sorted
     */
    public void bubbleSort(int[] array) {
        int bottom = array.length - 1;
        boolean swapped = true;

        while (swapped) {
            swapped = false;
            for (int i = 0; i < bottom; i++) {
                if (ascending && (array[i] > array[i + 1])) {
                    int temp = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = temp;
                    swapped = true;
                } else if (array[i] < array[i + 1]) {
                    int temp = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = temp;
                    swapped = true;
                }
            }
            bottom--;
        }
    }

    /**
     * Insertion Sorting Method
     * @param array - Array to be sorted
     */
    public void insertionSort(int[] array) {
        int size = array.length - 1;
        for (int i = 0; i < size; i++) {
            while (i > 0) {
                if (ascending && array[i - 1] > array[i]) {
                    int temp = array[i];
                    array[i] = array[i - 1];
                    array[i - 1] = temp;
                    i--;
                } else if (array[i - 1] < array[i]) {
                    int temp = array[i];
                    array[i] = array[i - 1];
                    array[i - 1] = temp;
                    i--;
                }
            }
        }
    }

    /**
     * Recursive Quick Sorting Method
     * @param array - Array to be sorted
     * @param low - Lowest index of the array
     * @param high - Highest index of the array
     */
    public void quickSort(int[] array, int low, int high) {
        if (low < high) {
            int pi = partition(array, low, high);

            quickSort(array, low, pi - 1);
            quickSort(array, pi + 1, high);
        }
    }

    /**
     * Actually Sorting of Quick Sort
     * @param array - Array to be sorted
     * @param low - Lowest index of the array
     * @param high - Highest index of the array
     * @return - Position of the pivot
     */
    private int partition(int[] array, int low, int high) {
        int pivot = array[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (ascending && array[j] <= pivot) {
                i++;
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            } else if (array[j] >= pivot) {
                i++;
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            
            }
        }
        int temp = array[i + 1];
        array[i + 1] = array[high];
        array[high] = temp;

        // return the position from where partition is done
        return (i + 1);
    }

    /**
     * Recursive Merge Sorting Method
     * @param array - Array to be sorted
     * @param low - Lowest index of the array
     * @param high - Highest index of the array
     */
    public void mergeSort(int array[], int low, int high) {
        if (low < high) {
            // Find the middle point
            int m = low + (high - low) / 2;

            // Splitting the array into halve continously until the arrays are one index
            // long
            mergeSort(array, low, m);
            mergeSort(array, m + 1, high);

            // once no more can be split then start merging the smallest arrays

            // Merge the sorted halves
            mergeHalves(array, low, m, high);
        }
    }

    /**
     * Actual Sorting of Merge Sort
     * @param array - Array to be sorted
     * @param low - Lowest index of the array
     * @param mid - Middle index of the array
     * @param high - Highest index of the array
     */
    private void mergeHalves(int array[], int low, int mid, int high) {
        // Find sizes of two subarrays to be merged
        int n1 = mid - low + 1;
        int n2 = high - mid;

        // Create temp arrays
        int L[] = new int[n1];
        int R[] = new int[n2];

        // Copy data to temp arrays
        for (int i = 0; i < n1; i++) {
            L[i] = array[low + i];
        }
        for (int j = 0; j < n2; j++) {
            R[j] = array[mid + 1 + j];
        }

        // Initial indexes of first and second subarrays
        int i = 0, j = 0;

        // Initial index of merged subarray array
        int k = low;

        // Actual merge. Basically, look where you are in the arrays, if you havent made
        // it to the end then continue.
        // Check to see which value is smaller, the move that into the new sorted array.
        // If you have reached the end of one array, copy the rest of the other array
        // into the sorted array.
        
        while (i < n1 && j < n2) {
            if (ascending) {
                if (L[i] <= R[j]) {
                    array[k] = L[i];
                    i++;
                } else {
                    array[k] = R[j];
                    j++;
                }
                k++;
            } else {
                if (L[i] <= R[j]) {
                    array[k] = L[i];
                    i++;
                } else {
                    array[k] = R[j];
                    j++;
                }
                k++;
            }
        }

        /* Copy remaining elements of L[] if any */
        while (i < n1) {
            array[k] = L[i];
            i++;
            k++;
        }

        /* Copy remaining elements of R[] if any */
        while (j < n2) {
            array[k] = R[j];
            j++;
            k++;
        }

    }


    /**
     * Clones and returns a new Sorter object
     * @return - Clone of Sorter Object
     */
    public Sorter clone() {
        return new Sorter(ascending);
    }

    /**
     * Returns true if the Sorter is equal to another Sorter object
     * @param other - Another Sorter Object
     * @return - a Boolean
     */
    public boolean equals(Sorter other) {
        if (ascending == other.ascending) {
            return true;
        }
        return false;
    }

    /**
     * Returns a String representation of the Sorter Object
     * @return - a String
     */
    public String toString() {
        return "Sorter: [ascending = " + ascending + "]";
    }

}
